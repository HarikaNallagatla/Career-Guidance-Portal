﻿using Casestudy.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Windows.Forms;

namespace Casestudy.Controllers
{
    public class MentorRegisterController : Controller
    {
        CareerGuidancePortalEntities2 db = new CareerGuidancePortalEntities2();

        // GET: MentorRegister
        public ActionResult MentorRegister()
        {
            return View();
        }
        [HttpPost]
        public ActionResult MentorRegister(tblMentor m1)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    CareerGuidancePortalEntities2 db = new CareerGuidancePortalEntities2();
                    m1.RoleId = 2;
                    db.ps_MentorRegister(m1.MentorName, m1.Email, m1.Password, m1.ConfirmPassword, m1.Phonenumber, m1.Experience, m1.Technology, m1.RoleId);
                    db.SaveChanges();
                    return RedirectToAction("Login", "Login");
                }
                else
                    return View();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            return View();
        }

        [HttpPost]
        public JsonResult doesEmailExist(string Email)
        {
            var user = db.tblUsers.Where(u => u.Email == Email).FirstOrDefault();
            return Json(user == null);
        }
    }
}