﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Casestudy.Controllers
{
    public class EngineeringController : Controller
    {
        // GET: Engineering
        public ActionResult Engineering()
        {
            return View();
        }
    }
}