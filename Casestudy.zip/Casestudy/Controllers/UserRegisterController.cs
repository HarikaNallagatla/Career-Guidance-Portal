﻿using Casestudy.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Windows.Forms;

namespace Casestudy.Controllers
{
    public class UserRegisterController : Controller
    {
        CareerGuidancePortalEntities2 db = new CareerGuidancePortalEntities2();

        // GET: UserRegister
        public ActionResult UserRegister()
        {
            return View();
        }

        [HttpPost]
        public ActionResult UserRegister(tblUser u1)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    CareerGuidancePortalEntities2 db = new CareerGuidancePortalEntities2();
                    u1.RoleId = 1;
                    db.ps_UserRegister(u1.UserName, u1.Email, u1.Password, u1.ConfirmPassword, u1.RoleId);
                    db.SaveChanges();
                    return RedirectToAction("Login", "Login");
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            
            return View(u1);
        }
        [HttpPost]
        public JsonResult doesEmailExist(string Email)
        {
            tblUser user = new tblUser();
            try
            {
               user = db.tblUsers.Where(u => u.Email == Email).FirstOrDefault();
                

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
               
            }
            return Json(user == null);
        }
    }
}