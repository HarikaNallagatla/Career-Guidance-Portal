﻿using Casestudy.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Windows.Forms;

namespace Casestudy.Controllers
{
    public class UserHomeController : Controller
    {
        CareerGuidancePortalEntities9 db = new CareerGuidancePortalEntities9();
        CareerGuidancePortalEntities2 data = new CareerGuidancePortalEntities2();
        CareerGuidancePortalEntities10 careers = new CareerGuidancePortalEntities10();
        CareerGuidancePortalEntitiesForumsData forums = new CareerGuidancePortalEntitiesForumsData();
        // GET: UserHome
       
        public ActionResult Home()
        {
            try
            {
                if (Session["Email"].ToString() != null)
                {
                    return View();
                }
                else
                    return RedirectToAction("Login", "Login");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            return RedirectToAction("Login", "Login");


        }



        public ActionResult Forums()
        {
            try
            {
                if (Session["Email"] != null)
                {
                    List<Forums> list = new List<Models.Forums>();
                    var results = db.ps_getAnswers();
                    foreach (var item in results)
                    {
                        list.Add(new Forums()
                        {
                            Question = item.Question,
                            postedBy = item.Posted_by,
                            AnsweredBy = item.Answered_by,
                            Answers = item.Answers,
                            Question_Id = item.Question_Id
                        });
                    }

                    return View(list);
                }
                else
                    return RedirectToAction("Login", "Login");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            return RedirectToAction("Login", "Login");


        }


        public ActionResult ChangePwd()
        {
            try
            {
                if (Session["Email"].ToString() != null)
                {

                    return View();
                }
                else
                    return RedirectToAction("Login", "Login");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            return RedirectToAction("Login", "Login");

        }

        [HttpPost]
        public ActionResult ChangePwd(ChangePassword ch)
        {
            try
            {
                if (Session["Email"].ToString() != null)
                {
                    if (ModelState.IsValid)
                    {
                        var user = data.tblUsers.Where(x => x.Password == ch.OldPassword && x.Email == ch.Email).FirstOrDefault();
                        if (user != null)
                        {
                            user.Password = ch.NewPassword;
                            db.SaveChanges();
                            return RedirectToAction("Login", "Login");
                        }
                        else
                        {
                            ModelState.AddModelError("", "Invalid  Credentials!");
                            return View();
                        }
                    }
                    else
                        return View();
                }
                else
                    return RedirectToAction("Login", "Login");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                
            }
            return RedirectToAction("Login", "Login");
        }

        public JsonResult Search(string term)
        {
            List<string> course;
           

                course = careers.tblCareers.Where(x => x.careerName.StartsWith(term)).Select(y => y.careerName).ToList();
               

            
            return Json(course, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult SearchCareer(string search)
        {
            switch (search)
            {

                case "Engineering":
                    return RedirectToAction("Engineering", "UserHome");
                case "Medicine":
                    return RedirectToAction("Medicine", "UserHome");
                case "FilmDirection":
                    return RedirectToAction("FilmDirection", "UserHome");
                case "Law":
                    return RedirectToAction("Lawyer", "UserHome");
                case "Management":
                    return RedirectToAction("Management", "UserHome");

                default:
                    MessageBox.Show("No results found");
                    return RedirectToAction("Home", "UserHome");
            }

        }

        public ActionResult Engineering()
        {
            CareerGuidancePortalEntities4 db = new CareerGuidancePortalEntities4();
           List<tblInstitution> data = new List<tblInstitution>();
            try
            {
                data = db.tblInstitutions.ToList();

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

            return View(data);
        }
     
        public ActionResult Medicine()
        {
            CareerGuidancePortalEntities4 db = new CareerGuidancePortalEntities4();
            List<tblInstitution> data = new List<tblInstitution>();
            try
            {
                data = db.tblInstitutions.ToList();

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

            return View(data);
        }
        
        public ActionResult FilmDirection()
        {
            CareerGuidancePortalEntities4 db = new CareerGuidancePortalEntities4();
            List<tblInstitution> data = new List<tblInstitution>();
            try
            {
                data = db.tblInstitutions.ToList();

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

            return View(data);
        }
       
        public ActionResult Lawyer()
        {
            CareerGuidancePortalEntities4 db = new CareerGuidancePortalEntities4();
            List<tblInstitution> data = new List<tblInstitution>();
            try
            {
                data = db.tblInstitutions.ToList();

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

            return View(data);
        }


      
        public ActionResult Management()
        {
            CareerGuidancePortalEntities4 db = new CareerGuidancePortalEntities4();
            List<tblInstitution> data = new List<tblInstitution>();
            try
            {
                data = db.tblInstitutions.ToList();

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

            return View(data);
        }

      
        public ActionResult ArtsandSciences()
        {
            CareerGuidancePortalEntities4 db = new CareerGuidancePortalEntities4();
            List<tblInstitution> data = new List<tblInstitution>();
            try
            {
                data = db.tblInstitutions.ToList();

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

            return View(data);
        }

     
        [HttpPost]
        public ActionResult UserQuestion(string QuestionBox)
        {
            try
            {
                string a = Session["Email"].ToString();
                var user = data.tblUsers.Where(x => x.Email == a).FirstOrDefault();
                tblForum quest = new tblForum();
                quest.Question = QuestionBox;
                quest.Posted_by = user.UserName;
                forums.tblForums.Add(quest);
                forums.SaveChanges();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
           
            return Content("Question is Submitted Successfully");
        }

        public ActionResult MentorDetails()
        {
            var mentordetails = data.tblMentors;
            return View(mentordetails);
        }
        
        public ActionResult LogOff()
        {
            Session.Abandon();
            return RedirectToAction("Login", "Login");
        }

    }
}