﻿using Casestudy.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Windows.Forms;

namespace Casestudy.Controllers
{
    public class LoginController : Controller
    {
        CareerGuidancePortalEntities2 db = new CareerGuidancePortalEntities2();
        // GET: Login
        public ActionResult Login()
        {
            ViewBag.Name = new SelectList(db.tblRoles.ToList(), "RoleName", "RoleName");
            return View();
        }
         [HttpPost]
        public ActionResult Login(LoginCredentials lc)
        {
            if (ModelState.IsValid)
            {
                if (lc.UserRoles == "User")
                {
                    try
                    {
                        var user = db.tblUsers.Where(u => u.Email == lc.Email && u.Password == lc.Password).FirstOrDefault();

                        if (user != null)
                        {
                            Session["Email"] = lc.Email;
                            MessageBox.Show("Logged in Successfully");
                            return RedirectToAction("Home", "UserHome");

                        }
                        else
                        {
                            ModelState.AddModelError("", "Invalid Login Credentials");
                            return View();
                        }
                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show(ex.Message);
                    }
                   

                }
                else if (lc.UserRoles == "Mentor")
                {
                    try
                    {
                        var mentor = db.tblMentors.Where(m => m.Email == lc.Email && m.Password == lc.Password).FirstOrDefault();
                        if (mentor != null)
                        {
                            Session["Email"] = lc.Email;
                            MessageBox.Show("Logged in Successfully");

                            return RedirectToAction("Forums", "MentorHome");
                        }
                        else
                        {
                            ModelState.AddModelError("", "Invalid Login Credentials");
                            return View();
                        }

                    }
                    catch (Exception ex)
                    {


                        MessageBox.Show(ex.Message);
                    }
                    
                }
                else
                {
                    ModelState.AddModelError("error", "Please select the UserRole");
                }
            }
            return View();
        }
    }
}