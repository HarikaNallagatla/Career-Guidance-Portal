﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Casestudy.Models
{
    public class Forums
    {
        public string Question { get; set; }
        public string Answers { get; set; }
        public string postedBy { get; set; }
        public string AnsweredBy { get; set; }
        public int? Likes { get; set; }
        public int Question_Id { get; set; }
    }
}